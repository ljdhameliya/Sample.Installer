﻿using System;

namespace Sample.Installer.Installer
{
    internal class DataContractAttribute : Attribute
    {
    }
}
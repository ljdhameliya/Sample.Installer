﻿using Microsoft.Deployment.WindowsInstaller;
using System;
using System.Configuration;
using System.Linq;
using System.Windows.Forms;
using Sample.Installer.Installer;
using WixSharp;
using WixSharp.CommonTasks;
using WixSharpSetup.Dialogs;

namespace WixSharpSetup
{
    public class Program
    {
        private static void Main(String[] args)
        {
            GenerateInstaller();
        }

        private static void GenerateInstaller()
        {
            // update code as per your installer path
            string path = @"E:\Projects\Sample\CodeBase\Devlopment\Sample.Installer\bin\Release\*.*"; // files need to add in installer
            string FileName = ".xml";

            Predicate<string> condition = new Predicate<string>(f => !f.EndsWith(FileName)); // not add into .msi file
            var data = new Files(path, condition);

            var project = new ManagedProject("Sample.Installer",
                          new Dir(@"%ProgramFiles%\Sample\Sample.Installer"
                          , new Files(path, condition)
                              ));

            project.SetNetFxPrerequisite("WIX_IS_NETFRAMEWORK_461_OR_LATER_INSTALLED >= '#394254'",
              "requires .NET Framework 4.6.1 or higher."); // check for .net framework Prerequisite
            project.GUID = new Guid("6fe30b47-2577-43ad-9095-1861ba25889b");

            project.ResolveWildCards()
           .FindFile((f) => f.Name.EndsWith("Sample.Installer.exe")).First()
           .Shortcuts = new[] {
                               new FileShortcut("Sample.Installer.exe", "INSTALLDIR"),
                               new FileShortcut("Sample.Installer.exe", "%Desktop%") // shortcut of project .exe file on desktop you can change file name aslo as per requirement.
                          };

            project.ManagedUI = new ManagedUI();
            project.ManagedUI.InstallDialogs.Add(WixSharp.Forms.Dialogs.Welcome)
                                        .Add(WixSharp.Forms.Dialogs.Licence)
                                        .Add(WixSharp.Forms.Dialogs.InstallDir)
                                        .Add(WixSharp.Forms.Dialogs.Progress)
                                        .Add(WixSharp.Forms.Dialogs.Exit);

            project.BeforeInstall += Msi_BeforeInstall;

            ValidateAssemblyCompatibility();

            project.BuildMsi();
        }

        private static void Msi_BeforeInstall(SetupEventArgs e)
        {
            if (e.IsInstalling && !e.IsUninstalling)
            {
                // check condition when setup is installing
            }
        }

        private static void ValidateAssemblyCompatibility()
        {
            var assembly = System.Reflection.Assembly.GetExecutingAssembly();

            if (!assembly.ImageRuntimeVersion.StartsWith("v2."))
            {
                Console.WriteLine("Warning: assembly '{0}' is compiled for {1} runtime, which may not be compatible with the CLR version hosted by MSI. " +
                                  "The incompatibility is particularly possible for the EmbeddedUI scenarios. " +
                                   "The safest way to solve the problem is to compile the assembly for v3.5 Target Framework.",
                                   assembly.GetName().Name, assembly.ImageRuntimeVersion);
            }
        }
    }
}
